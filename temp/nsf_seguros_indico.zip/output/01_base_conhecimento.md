# 01_base_conhecimento.md

## Projeto: NSF_Seguros_Indico - Base de Conhecimento

### Regras de Negócio (RN)

* RN1: Cada usuário (Indicador) recebe um código de indicação único.
* RN2: Um indicado só pode ser associado a um único indicador.
* RN3:  O desconto para o indicado é aplicado somente após a aprovação da sua apólice de seguro.
* RN4: O indicador recebe uma recompensa (a ser definida) pela indicação aprovada.
* RN5:  O sistema deve registrar todas as indicações, seu status (pendente, aprovado, rejeitado) e data.
* RN6: O sistema deve emitir notificações push para o indicador e indicado sobre o status da indicação.
* RN7:  O administrador do sistema tem acesso a todos os dados e pode gerenciar usuários, seguros e indicações.
* RN8: O sistema deve garantir a segurança dos dados dos usuários, seguindo as melhores práticas de segurança.


### Requisitos Funcionais (RF)

* RF1: Cadastro de usuário (Indicador e Indicado).
* RF2: Gerenciamento de perfil de usuário.
* RF3: Indicar um seguro (fornecendo o código de indicação).
* RF4: Visualização de indicações (para indicadores e administradores).
* RF5: Sistema de notificações push (para indicadores e indicados).
* RF6:  Gerenciamento de descontos para indicados.
* RF7: Relatórios para o administrador (indicados, indicadores, descontos aplicados, etc.).
* RF8:  Painel administrativo para gerenciamento completo do sistema.
* RF9: Integração com API de seguros (se necessário).


### Requisitos Não Funcionais (RNF)

* RNF1:  Escalabilidade: O sistema deve suportar um grande número de usuários e indicações.
* RNF2:  Performance: O sistema deve ser responsivo e rápido.
* RNF3:  Segurança: O sistema deve proteger os dados dos usuários contra acesso não autorizado.
* RNF4:  Disponibilidade: O sistema deve estar disponível 24/7.
* RNF5:  Usabilidade: O sistema deve ser fácil de usar e intuitivo para todos os tipos de usuários.
* RNF6:  Manutenibilidade: O sistema deve ser fácil de manter e atualizar.
* RNF7:  Portabilidade: O aplicativo deve funcionar em diferentes dispositivos móveis (Android e iOS).


### Personas de Usuário

* **Indicador:** Usuário que deseja indicar seguros e ganhar recompensas.
* **Indicado:** Usuário que recebe a indicação de seguro e pode obter descontos.
* **Administrador:** Usuário com privilégios completos para gerenciar o sistema.


### Fluxos de Usuário

* **Fluxo 1 (Indicar Seguro):** Indicador acessa o app, escolhe um seguro, insere os dados do indicado (nome e telefone ou email) e envia a indicação.
* **Fluxo 2 (Receber Indicação):** Indicado recebe um link ou código, acessa o app, preenche informações para o seguro e aguarda aprovação.
* **Fluxo 3 (Gerenciar Indicações):** Indicador acompanha o status das suas indicações no app.
* **Fluxo 4 (Receber Notificação):** Indicador e indicado recebem notificações push sobre o status da indicação (aprovada, rejeitada, etc.).
* **Fluxo 5 (Administração):** Administrador acessa o painel administrativo para visualizar relatórios, gerenciar usuários, etc.

