# 02_arquitetura_tecnica.md

## Arquitetura

Será utilizada uma arquitetura de microsserviços para maior escalabilidade, manutenibilidade e flexibilidade.  Os microsserviços serão:

* **Usuário:** Gerenciamento de usuários (Indicadores e Indicados), autenticação e autorização.
* **Seguro:** Catálogo de seguros, integração com APIs de seguradoras (se necessário).
* **Indicação:**  Gerenciamento do processo de indicação, incluindo status e recompensas.
* **Notificação:**  Envio de notificações push (Android e iOS).
* **Gamificação:**  Sistema de pontos e recompensas para Indicadores.
* **Desconto:**  Gerenciamento de descontos para Indicados.

Cada microsserviço será independente e poderá ser desenvolvido e implantado separadamente.  A comunicação entre os microsserviços será feita via APIs RESTful.  Um gateway de API será utilizado para roteamento e segurança.

## Tecnologias

* **Frontend:** React Native (para iOS e Android), ou Flutter, visando uma base de código única.
* **Backend:** Node.js com Express.js (por sua escalabilidade e performance) ou Python com Flask/Django.
* **Banco de Dados:** PostgreSQL (por sua robustez e escalabilidade) ou MongoDB (para maior flexibilidade caso haja necessidade de dados não estruturados).
* **Mensageria:** RabbitMQ ou Kafka para comunicação assíncrona entre microsserviços (para notificações, por exemplo).
* **Notificações Push:** Firebase Cloud Messaging (FCM) ou similar.
* **Gateway API:** Kong ou similar.
* **Testes:** Jest (Javascript), pytest (Python), ferramentas de integração contínua (CI/CD).
* **Infraestrutura:** Cloud provider como AWS, GCP ou Azure (a escolha dependerá de fatores como custo e requisitos específicos).


## Integrações

* **APIs de Seguradoras:**  Integração com APIs de seguradoras para obtenção de informações sobre os seguros e processamento de compras (se aplicável). Esta integração dependerá da disponibilidade de APIs por parte das seguradoras parceiras e precisará ser detalhada em um documento separado.
* **Serviços de Notificação Push:** Integração com FCM ou serviço similar.


## Fluxos Principais

**1. Fluxo de Indicação:**

1. O Indicador acessa o aplicativo e seleciona um seguro para indicar.
2. O aplicativo valida o usuário e o seguro.
3. O Indicador insere os dados do Indicado (e-mail ou telefone).
4. O sistema envia uma notificação push para o Indicado com o convite e os dados do Indicador.
5. O Indicado aceita a indicação, possivelmente através de um link no push ou diretamente no app.
6. O sistema registra a indicação e atualiza o status.
7. Após aprovação do seguro pelo Indicado, o Indicador e o Indicado recebem notificações (indicador parabenizando, indicado com dados de contato do consultor).
8. O sistema atribui pontos ao Indicador (Gamificação).

**2. Fluxo de Gerenciamento de Indicações:**

1. O Indicador acessa a seção "Minhas Indicações".
2. O sistema exibe a lista de indicações, com status e recompensas acumuladas.

**3. Fluxo de Resgate de Desconto:**

1. O Indicado acessa a seção "Meus Descontos".
2. O sistema exibe os descontos disponíveis.
3. O Indicado seleciona o desconto e aplica-o ao processo de compra do seguro.

**4. Fluxo de Administração:**

1. O administrador acessa o painel administrativo com autenticação.
2. O administrador pode visualizar relatórios, gerenciar usuários, seguros, indicações e descontos.
3. O administrador pode configurar parâmetros do sistema de gamificação e descontos.

Os fluxos acima representam os principais fluxos do sistema. Outros fluxos menores serão definidos durante a fase de design detalhado.
