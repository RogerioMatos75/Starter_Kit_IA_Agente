# 04_fluxos_usuario.md

## Fluxos de Usuário:

### Fluxo 1: Indicador - Indicar um Seguro

1. **Login:** O usuário (Indicador) faz login no aplicativo.
2. **Tela Principal:** O usuário visualiza sua tela principal com opções para indicar um seguro, gerenciar indicações e visualizar recompensas.
3. **Indicar Seguro:** O usuário seleciona a opção "Indicar Seguro".
4. **Selecionar Seguro:** O usuário seleciona o tipo de seguro a ser indicado.
5. **Preencher Dados do Indicado:** O usuário preenche os dados do indicado (nome, telefone, e-mail).
6. **Confirmação:** O usuário confirma a indicação.
7. **Sucesso:** O sistema envia uma notificação push ao Indicador confirmando a indicação e uma notificação push ao Indicado com informações sobre a indicação e o contato do Indicador.  O sistema registra a indicação.
8. **Monitoramento:** O Indicador pode monitorar o status da indicação na seção "Gerenciar Indicações".

### Fluxo 2: Indicado - Receber Indicação

1. **Notificação Push:** O Indicado recebe uma notificação push informando sobre uma indicação de seguro.
2. **Abrir Aplicativo:** O Indicado abre o aplicativo.
3. **Detalhes da Indicação:** O Indicado visualiza os detalhes da indicação, incluindo o nome do Indicador e o tipo de seguro.
4. **Contato com Consultor:** O sistema indica que um consultor entrará em contato em breve.
5. **Acompanhamento:** O Indicado pode acompanhar o andamento da indicação.
6. **Aprovação da Indicação:** Após a aprovação, o Indicado recebe informações sobre o desconto.


### Fluxo 3: Indicador - Gerenciar Indicações

1. **Login:** O usuário (Indicador) faz login no aplicativo.
2. **Tela Principal:** O usuário seleciona a opção "Gerenciar Indicações".
3. **Lista de Indicações:** O usuário visualiza uma lista de suas indicações, com status (pendente, aprovado, rejeitado).
4. **Detalhes da Indicação:** O usuário pode visualizar os detalhes de cada indicação.
5. **Gamificação:** O usuário acompanha suas recompensas pelo sistema de gamificação.


### Fluxo 4: Indicado - Resgatar Desconto

1. **Aprovação da Indicação:** A indicação do Indicado é aprovada.
2. **Notificação Push:** O Indicado recebe notificação sobre o desconto.
3. **Tela Principal:** O Indicado acessa sua tela principal.
4. **Resgatar Desconto:** O Indicado seleciona a opção para resgatar o desconto.
5. **Código de Desconto:** O sistema gera um código de desconto.
6. **Utilização do Desconto:** O Indicado utiliza o código de desconto no processo de contratação do seguro.


## Navegação:

A navegação será intuitiva, com menus de fácil acesso e uma estrutura clara.  A tela principal apresentará os principais recursos, permitindo acesso rápido às funcionalidades. Será utilizada uma navegação em Tabs ou Drawer, dependendo da plataforma (web ou mobile).

## Interações:

As interações serão simples e diretas, utilizando botões claros e mensagens de feedback.  O sistema fornecerá notificações push para manter os usuários informados sobre o status de suas indicações e recompensas.  Formulários serão concisos, solicitando apenas as informações essenciais.  Será utilizada uma linguagem clara e objetiva em todas as mensagens e interfaces.
