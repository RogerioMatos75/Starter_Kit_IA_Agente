# 06_autenticacao_backend.md

## Sugestão de Autenticação Backend para NSF_Seguros_Indico

### Método de Autenticação: JWT (JSON Web Tokens)

### Fluxo de Autenticação:

1. **Registro:** O usuário cria uma conta fornecendo informações como e-mail e senha. A senha deve ser armazenada com hash usando um algoritmo seguro como bcrypt ou Argon2.
2. **Login:** O usuário envia seu e-mail e senha para o backend.
3. **Verificação:** O backend verifica se o e-mail existe e compara o hash da senha fornecida com o hash armazenado no banco de dados.
4. **Geração do JWT:** Se as credenciais forem válidas, o backend gera um JWT contendo informações do usuário (ID, e-mail, tipo de usuário - indicador, indicado ou administrador) e uma assinatura digital.
5. **Resposta:** O JWT é retornado ao cliente.
6. **Autenticação subsequente:** Em todas as requisições subsequentes, o cliente inclui o JWT no cabeçalho da requisição (ex: `Authorization: Bearer <token>`).
7. **Validação do JWT:** O backend valida o JWT verificando a assinatura e a expiração. Se o JWT for válido, o usuário é autenticado.


### Tecnologias/Bibliotecas:

* **Linguagem de programação:** Node.js com Express.js (ou similar como Python com Django/Flask)
* **Biblioteca JWT:** jsonwebtoken (Node.js) ou PyJWT (Python)
* **Banco de dados:** PostgreSQL, MySQL ou MongoDB (com escolha adequada de driver)
* **Algoritmo de hashing:** bcrypt ou Argon2


### Considerações de Segurança:

* **Armazenamento de senhas:** Nunca armazene senhas em texto plano. Utilize sempre um algoritmo de hashing unidirecional com sal e rounds adequados.
* **Validação de entrada:** Valide todas as entradas do usuário para prevenir ataques de injeção (SQL Injection, XSS, etc.).
* **Proteção contra ataques de força bruta:** Implemente mecanismos para limitar tentativas de login inválidas.
* **HTTPS:** Utilize HTTPS para proteger a comunicação entre o cliente e o servidor.
* **Segurança de Sessão (se aplicável):**  JWT reduz a necessidade de gerenciamento de sessão no lado do servidor, mas se forem usados cookies de sessão, assegure-se de utilizar cookies HttpOnly e Secure.
* **Atualização regular de dependências:** Mantenha todas as bibliotecas e dependências atualizadas para corrigir vulnerabilidades de segurança conhecidas.
* **Auditoria:**  Registrar todas as tentativas de login e outras ações sensíveis para fins de auditoria e detecção de intrusões.
* **Proteção contra CSRF (Cross-Site Request Forgery):** Implementar mecanismos de proteção contra CSRF, como tokens CSRF.
* **Tratamento de erros:** Implementar tratamento de erros robusto e seguro, evitando vazamento de informações sensíveis em mensagens de erro.
* **Testes de segurança:** Realizar testes de penetração regulares para identificar e corrigir vulnerabilidades.

