# 05_backlog_mvp.md

## NSF_Seguros_Indico - Backlog MVP

### Funcionalidades (Épicos e User Stories)

**Épico 1: Fluxo de Indicação**

* **User Story 1:** Como um indicador, eu quero indicar um seguro para um amigo, para que ele receba um desconto e eu ganhe uma recompensa.
* **User Story 2:** Como um indicado, eu quero receber uma notificação sobre a indicação de seguro, para que eu saiba quem me indicou e possa aproveitar o desconto.
* **User Story 3:** Como um administrador, eu quero visualizar um painel com todas as indicações realizadas, para monitorar o sucesso da campanha.

**Épico 2: Gerenciamento de Indicação**

* **User Story 4:** Como um indicador, eu quero acompanhar o status das minhas indicações (aprovadas, rejeitadas, pendentes), para monitorar meu desempenho e as recompensas.
* **User Story 5:** Como um indicado, eu quero visualizar os detalhes da indicação recebida, incluindo o valor do desconto e o nome do indicador.

**Épico 3: Notificações**

* **User Story 6:** Como um indicador, eu quero receber uma notificação push quando uma indicação minha for aprovada.
* **User Story 7:** Como um indicado, eu quero receber uma notificação push com os detalhes da indicação e o nome de quem me indicou.

**Épico 4: Sistema de Recompensas**

* **User Story 8:** Como um indicador, eu quero receber uma recompensa (desconto ou outro benefício) quando uma indicação minha for aprovada.
* **User Story 9:** Como um indicado, eu quero visualizar e resgatar o desconto oferecido na indicação.


### Critérios de Aceitação

* **User Story 1:** O sistema deve permitir ao indicador preencher os dados do indicado (nome, telefone, email) e o tipo de seguro desejado. Após o envio, o indicado deve receber uma notificação.  O sistema deve registrar a indicação e seu status.
* **User Story 2:** O indicado deve receber uma notificação push com o nome do indicador e os detalhes do desconto oferecido.
* **User Story 3:** O painel de administração deve exibir uma lista de todas as indicações, com filtros por data, status e indicador.
* **User Story 4:** A tela de gerenciamento de indicações deve mostrar o status de cada indicação (pendente, aprovada, rejeitada), data e valor da recompensa.
* **User Story 5:** A tela de detalhes da indicação deve mostrar o nome do indicador, o tipo de seguro, o valor do desconto e o prazo para resgate.
* **User Story 6:** A notificação push para o indicador deve incluir o nome do indicado e o status da indicação.
* **User Story 7:** A notificação push para o indicado deve incluir o nome do indicador, tipo de seguro e valor do desconto.
* **User Story 8:** O sistema deve calcular e registrar a recompensa para o indicador,  conforme as regras definidas.
* **User Story 9:** O sistema deve permitir ao indicado visualizar e resgatar o desconto durante um período definido.


### Priorização (MoSCoW)

**Must Have:**

* User Story 1 (Indicar Seguro)
* User Story 2 (Receber Indicação)
* User Story 6 (Notificação Indicador - Aprovação)
* User Story 7 (Notificação Indicado)

**Should Have:**

* User Story 3 (Painel de Administração - Visão Geral)
* User Story 4 (Gerenciar Indicações - Indicador)
* User Story 5 (Detalhes da Indicação - Indicado)

**Could Have:**

* User Story 8 (Recompensa Indicador)
* User Story 9 (Resgate Desconto Indicado)

**Won't Have (MVP):**  Nenhuma funcionalidade neste MVP.
