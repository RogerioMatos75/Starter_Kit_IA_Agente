# 03_regras_negocio.md

## Regras de Negócio

1. **Indicar Seguro:** Um usuário (Indicador) pode indicar um seguro para outro usuário (Indicado) através do aplicativo, fornecendo o nome e o contato do Indicado.  O Indicador deve possuir uma conta ativa no aplicativo. A indicação só será válida se o Indicado aceitar a indicação.

2. **Receber Indicação:** Um usuário (Indicado) receberá uma notificação push informando sobre a indicação de seguro recebida, incluindo o nome do Indicador.  O Indicado poderá aceitar ou rejeitar a indicação.

3. **Gerenciar Indicações:**  Tanto o Indicador quanto o Indicado podem visualizar o histórico de suas indicações, incluindo o status (pendente, aprovado, rejeitado), data e informações relevantes.

4. **Aprovação da Indicação:** A indicação só será considerada aprovada após a compra do seguro pelo Indicado.  Após a aprovação, ambos os usuários receberão notificações push. O Indicador receberá uma notificação parabenizando-o e o Indicado receberá uma notificação com os dados do Indicador e a informação de que um consultor entrará em contato.

5. **Notificação Push:** O sistema enviará notificações push para o Indicador e o Indicado conforme os eventos relevantes ocorrerem (nova indicação, aprovação, etc.).  O sistema deve considerar a possibilidade de notificações falhas.

6. **Desconto:** Ao ser aprovada a indicação, o Indicado receberá um desconto pré-definido no valor do seguro.  O valor do desconto será definido pela empresa e poderá variar dependendo da campanha.

7. **Resgatar Desconto:** O desconto será automaticamente aplicado ao preço do seguro do Indicado, caso a indicação seja aprovada e a compra seja efetuada.

8. **Sistema de Gamificação (futuro):** A implementação de um sistema de gamificação para recompensar os Indicadores por indicações bem sucedidas poderá ser implementada em futuras iterações.


## Restrições

1. Integração com APIs de Seguros: A integração com APIs de terceiros para validação de seguros e aplicação de descontos deverá ser definida e implementada posteriormente, caso necessário.

2.  Plataforma: A plataforma e tecnologias a serem utilizadas no desenvolvimento do aplicativo serão definidas em documento separado.

3.  Escalabilidade: O sistema deve ser desenhado para suportar um número crescente de usuários e indicações.


## Exceções

1. **Falha na Notificação Push:**  Se a notificação push falhar, o sistema deverá registrar o erro e tentar novamente após um determinado tempo. Uma notificação adicional será enviada, garantindo o recebimento da informação.

2. **Rejeição da Indicação:** Se o Indicado rejeitar a indicação, ambos os usuários serão notificados e a indicação será marcada como rejeitada.

3. **Indicado já Cliente:** Se o Indicado já for cliente da seguradora, o sistema deverá verificar e validar o funcionamento do sistema de descontos.


## Decisões

1. **Escopos iniciais:**  O escopo inicial do projeto se concentrará nas funcionalidades principais: Indicar Seguro, Receber Indicação, Gerenciar Indicações, Receber Notificação e Resgatar Desconto.  A gamificação será considerada em etapas futuras.

2. **Integração com Seguradoras:** A integração com as APIs das seguradoras será considerada em uma fase posterior do projeto, dependendo da necessidade e viabilidade.  Inicialmente, o foco será na funcionalidade core do aplicativo.

3. **Plataforma:** A decisão sobre a tecnologia específica para o desenvolvimento do aplicativo será tomada após análise mais detalhada.
