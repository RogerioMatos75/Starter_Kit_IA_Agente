```jsx
import React, { useState, useEffect } from 'react';

const App = () => {
  const [data, setData] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch('/api/data'); // Substitua '/api/data' pelo endpoint correto
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        const jsonData = await response.json();
        setData(jsonData);
      } catch (error) {
        setError(error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, []);

  if (isLoading) {
    return <div>Carregando...</div>;
  }

  if (error) {
    return <div>Erro: {error.message}</div>;
  }

  return (
    <div>
      <h1>Dados do Backend</h1>
      <ul>
        {data.map((item) => (
          <li key={item.id}>{item.name}</li> // Adapte para os campos do seu objeto
        ))}
      </ul>
    </div>
  );
};

export default App;
```
