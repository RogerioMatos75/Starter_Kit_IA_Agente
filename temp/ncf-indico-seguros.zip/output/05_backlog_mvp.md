# 05_backlog_mvp.md

## NCF-Indico-Seguros - Backlog MVP

### Funcionalidades (Épicos e User Stories)

**Épico 1: Fluxo de Indicação**

* **User Story 1:** Como um indicador, eu quero indicar um seguro para um amigo, para que ele possa receber um desconto.
* **User Story 2:** Como um indicado, eu quero receber uma notificação sobre a indicação de seguro, para que eu saiba quem me indicou e possa aproveitar o desconto.
* **User Story 3:** Como um administrador, eu quero visualizar todas as indicações realizadas, para que eu possa monitorar o desempenho da plataforma.

**Épico 2: Gerenciamento de Indicador**

* **User Story 4:** Como um indicador, eu quero visualizar minhas indicações e acompanhar seu status (pendente, aprovado, rejeitado), para que eu possa acompanhar meu desempenho e os descontos a serem ganhos.

**Épico 3: Gerenciamento de Indicado**

* **User Story 5:** Como um indicado, eu quero visualizar os detalhes da indicação recebida, incluindo o nome do indicador e o desconto oferecido, para que eu possa entender o benefício da indicação.
* **User Story 6:** Como um indicado, eu quero resgatar o desconto na contratação do seguro, para que eu possa usufruir do benefício oferecido.

**Épico 4: Notificações Push**

* **User Story 7:** Como um indicador, eu quero receber uma notificação push quando uma indicação minha for aprovada, para que eu seja notificado do sucesso da indicação.
* **User Story 8:** Como um indicado, eu quero receber uma notificação push com os dados de quem me indicou, para que eu possa saber quem me recomendou.

**Épico 5: Autenticação e Segurança**

* **User Story 9:** Como um usuário, eu quero poder criar uma conta e fazer login de forma segura, para que eu possa acessar as funcionalidades do aplicativo.


### Critérios de Aceitação

* **User Story 1:** O sistema deve permitir que o indicador insira os dados do indicado (nome e contato), o tipo de seguro e um código de indicação.
* **User Story 2:** O indicado deve receber uma notificação push com as informações do indicador e o link para o seguro com desconto.
* **User Story 3:** O administrador deve acessar um painel com relatórios de todas as indicações, seus status e valores de descontos.
* **User Story 4:** O indicador deve visualizar uma lista com o status de cada indicação (pendente, aprovado, rejeitado).
* **User Story 5:** O indicado deve visualizar o nome do indicador, o valor do desconto e o link para contratar o seguro.
* **User Story 6:** O indicado deve poder aplicar o desconto durante o processo de contratação do seguro.
* **User Story 7:** Notificação push deve ser enviada para o indicador ao aprovar a indicação, contendo a data e o valor do desconto.
* **User Story 8:** Notificação push enviada ao indicado deve conter o nome do indicador e o código da indicação.
* **User Story 9:** O sistema deve garantir a segurança das informações do usuário através de criptografia e autenticação segura.


### Priorização (MoSCoW)

**Must Have:**

* User Story 1 (Indicar Seguro)
* User Story 2 (Receber Indicação - Indicado)
* User Story 7 (Notificação Push - Indicador)
* User Story 8 (Notificação Push - Indicado)
* User Story 9 (Autenticação e Segurança)


**Should Have:**

* User Story 3 (Visualização de Indicações - Admin)
* User Story 4 (Gerenciar Indicações - Indicador)


**Could Have:**

* User Story 5 (Detalhes da Indicação - Indicado)
* User Story 6 (Resgatar Desconto - Indicado)


**Won't Have (MVP):**

* Nenhum item para esta versão MVP.

