# 01_base_conhecimento.md

## Projeto: NCF-Indico-Seguros

### Regras de Negócio (RN)

* **RN1:** Cada usuário Indicador pode indicar quantos Seguros quiser para quantos Indicados quiser.
* **RN2:** Um Indicado só pode receber desconto por uma única indicação por Seguro, mesmo que seja indicado múltiplas vezes pela mesma pessoa.
* **RN3:** O desconto é concedido ao Indicado após a aprovação da solicitação do Seguro.
* **RN4:** O Indicador recebe uma notificação push quando uma indicação resulta na aprovação de um Seguro pelo Indicado.
* **RN5:** O Indicado recebe uma notificação push contendo informações do Indicador e a confirmação do desconto após a aprovação do Seguro.
* **RN6:** O sistema deve registrar todas as indicações, incluindo status (pendente, aprovado, rejeitado).
* **RN7:** O sistema de gamificação pode ser implementado com base em pontos acumulados por indicações aprovadas, com recompensas definidas posteriormente.
* **RN8:** A administração do sistema deve permitir a visualização de relatórios, gestão de usuários e controle de descontos.


### Requisitos Funcionais (RF)

* **RF1:** Cadastro de Usuários (Indicador e Indicado).
* **RF2:** Login seguro de usuários.
* **RF3:** Indicação de Seguro por um Indicador.
* **RF4:** Visualização de indicações por Indicador e Indicado.
* **RF5:** Aprovação/Rejeição de Seguro pelo Indicado.
* **RF6:** Envio de notificações push (para Indicador e Indicado).
* **RF7:** Gerenciamento de descontos.
* **RF8:** Painel administrativo para gerenciamento do sistema e relatórios.
* **RF9:** Sistema de Gamificação (opcional, a ser definido posteriormente).


### Requisitos Não Funcionais (RNF)

* **RNF1:** Alta disponibilidade e escalabilidade.
* **RNF2:** Segurança de dados (criptografia, autenticação robusta).
* **RNF3:** Performance adequada (tempos de resposta rápidos).
* **RNF4:** Interface intuitiva e amigável para todas as personas.
* **RNF5:** Compatibilidade com dispositivos móveis (iOS e Android).
* **RNF6:** Manutenibilidade e facilidade de atualização do sistema.
* **RNF7:** Integração com APIs de seguros (se aplicável).


### Personas de Usuário

* **Indicador:** Usuário que deseja indicar seguros para ganhar recompensas.
* **Indicado:** Usuário que recebe uma indicação de seguro e pode obter descontos.
* **Administrador:** Usuário com privilégios para gerenciar o sistema e visualizar relatórios.


### Fluxos de Usuário

* **Fluxo 1 (Indicador):** Cadastro/Login -> Selecionar Seguro -> Indicar para Indicado -> Acompanhar status da indicação -> Receber notificação de aprovação.
* **Fluxo 2 (Indicado):** Cadastro/Login -> Receber notificação de indicação -> Visualizar detalhes da indicação -> Aprovar/Rejeitar Seguro -> Receber desconto (se aprovado).
* **Fluxo 3 (Administrador):** Login -> Gerenciar usuários -> Gerenciar seguros -> Visualizar relatórios -> Gerenciar descontos.

