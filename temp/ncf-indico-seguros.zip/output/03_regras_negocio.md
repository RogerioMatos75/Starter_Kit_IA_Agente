# 03_regras_negocio.md

## Regras de Negócio

* **Indicação:** Um usuário (Indicador) pode indicar um seguro para outro usuário (Indicado) através do aplicativo.  A indicação deve conter informações mínimas: nome do Indicado e contato (e-mail ou telefone).
* **Aprovação da Indicação:**  A indicação só será considerada válida após a aprovação do seguro pelo Indicado.  A aprovação deve ser rastreada no sistema.
* **Notificações Push:** Após a aprovação da indicação, o Indicador receberá uma notificação push parabenizando-o pela indicação bem sucedida. O Indicado receberá uma notificação push com os dados do Indicador e a informação de que um consultor entrará em contato.
* **Desconto:** O Indicado receberá um desconto pré-definido no seguro adquirido através da indicação. O valor do desconto será configurado pelo administrador.
* **Gamificação:** O sistema de gamificação, caso implementado, terá regras definidas separadamente e detalhadas posteriormente.
* **Cadastro de Usuários:**  Usuários devem se cadastrar no aplicativo fornecendo informações necessárias para identificação e contato.
* **Administração:** O administrador terá acesso a um painel para monitorar indicações, usuários, descontos aplicados, e demais dados relevantes do sistema.

## Restrições

* **Integração com APIs externas:** A integração com APIs de seguros dependerá da disponibilidade e especificações das APIs de cada seguradora parceira.  Este ponto necessita de definição adicional.
* **Plataforma:** A escolha da plataforma (iOS, Android, Web) e suas respectivas restrições e custos devem ser considerados.
* **Segurança:** O aplicativo deve atender aos requisitos de segurança de dados e privacidade dos usuários.

## Exceções

* **Indicação Rejeitada:** Se o Indicado rejeitar o seguro indicado, a indicação será considerada inválida e o Indicador não receberá nenhuma recompensa.  Uma notificação pode ser enviada ao Indicador informando da rejeição.
* **Falha na Notificação Push:**  Em caso de falha na entrega da notificação push, o sistema deve registrar o erro e tentar novamente posteriormente.
* **Dados Incompletos:** Se o usuário não fornecer todas as informações necessárias para o cadastro ou indicação, o sistema deverá notificar o usuário e impedir a ação.
* **Fraude:** O sistema deve possuir mecanismos para detectar e prevenir fraudes relacionadas a indicações, como criação de contas falsas.

## Decisões

* **Modelo de Desconto:** O modelo de desconto para os indicados será definido em conjunto com o cliente (Regina Reine).
* **Plataforma Inicial:** A plataforma inicial para o MVP (Minimum Viable Product) será definida após análise detalhada de custos e recursos disponíveis.
* **Gamificação (opcional):** A implementação da gamificação poderá ser adiada para uma fase posterior do projeto, dependendo dos recursos e prioridades.
* **Integração com Seguradoras:** A integração com seguradoras será feita gradualmente, começando com um número limitado de parceiros.

