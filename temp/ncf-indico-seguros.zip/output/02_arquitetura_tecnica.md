# 02_arquitetura_tecnica.md

## Arquitetura

O sistema Archon será baseado em uma arquitetura de microsserviços, permitindo maior escalabilidade, manutenabilidade e flexibilidade.  Os microsserviços principais serão:

* **Serviço de Usuário:** Gerenciamento de usuários (Indicadores e Indicados), autenticação e autorização.
* **Serviço de Seguro:** Catálogo de seguros, integração com APIs de seguradoras (se aplicável).
* **Serviço de Indicação:** Gerenciamento de indicações, cálculo de descontos e regras de negócio.
* **Serviço de Notificação:** Envio de notificações push (Android e iOS).
* **Serviço de Gamificação:** Pontuação, recompensas e sistema de ranking para indicadores.
* **Gateway API:** Ponto único de entrada para todas as requisições.


## Tecnologias

* **Frontend:** React Native (para iOS e Android), possibilitando uma base de código única e melhorando a performance.
* **Backend:** Node.js com Express.js, oferecendo performance e escalabilidade, além de um vasto ecossistema de bibliotecas.
* **Banco de Dados:** PostgreSQL, por sua robustez, escalabilidade e suporte a transações complexas.  Redis para cache.
* **Mensageria:** RabbitMQ para comunicação assíncrona entre os microsserviços, garantindo a resiliência do sistema.
* **Cloud Provider:** AWS (ou similar), para infraestrutura como serviço (IaaS) e escalabilidade.
* **Notificações Push:** Firebase Cloud Messaging (FCM) para Android e Apple Push Notification service (APNs) para iOS.


## Integrações

* **API de Seguradoras:** Integração com APIs externas de seguradoras para obter informações sobre produtos de seguros, caso necessário.  Esta integração será abstraída através do microsserviço de Seguro.


## Fluxos Principais

**1. Fluxo de Indicação:**

1. O Indicador acessa o aplicativo e seleciona um seguro para indicar.
2. O Indicador fornece os dados do Indicado (e.g., nome, telefone, email).
3. O sistema valida os dados e cria uma nova indicação no Serviço de Indicação.
4. O Serviço de Notificação envia uma notificação push para o Indicado, contendo informações sobre a indicação e o Indicador.
5. O Indicado pode aceitar ou rejeitar a indicação no aplicativo.
6. Se a indicação for aprovada, o Indicador e o Indicado recebem notificações push. O Indicador ganha pontos no sistema de Gamificação e o Indicado recebe seu desconto.

**2. Fluxo de Gerenciamento de Indicações:**

1. O Indicador acessa a tela de gerenciamento de indicações.
2. O Serviço de Indicação retorna a lista de indicações do usuário.
3. O sistema exibe informações relevantes, como status da indicação, pontos ganhos, etc.

**3. Fluxo de Resgate de Desconto:**

1. O Indicado acessa a tela de resgate de desconto.
2. O sistema valida a elegibilidade do desconto.
3. O desconto é aplicado no momento da compra do seguro.

**4. Fluxo de Administração:**

O administrador terá acesso a um painel para gerenciar usuários, seguros, indicações e relatórios.  Este painel terá uma interface web separada.
