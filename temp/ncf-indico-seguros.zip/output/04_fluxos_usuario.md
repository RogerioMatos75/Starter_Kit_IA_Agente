# 04_fluxos_usuario.md

## Fluxos de Usuário

### Fluxo 1: Indicador - Indicar um Seguro

1. **Login:** O indicador acessa o aplicativo e realiza login.
2. **Tela Inicial:** Visualiza opções de seguros disponíveis e a opção "Indicar Seguro".
3. **Selecionar Seguro:** Escolhe o seguro a ser indicado.
4. **Preencher Dados do Indicado:** Insere informações de contato do indicado (nome, telefone, email).  Opcional: permite busca por contato na agenda do celular.
5. **Confirmação:** Confirma a indicação.
6. **Sucesso:** Recebe mensagem de confirmação e acompanhamento da indicação.
7. **Notificação (Push):**  Recebe notificação push confirmando a indicação e o status de aprovação do indicado.


### Fluxo 2: Indicado - Receber e Aceitar Indicação

1. **Notificação (Push):**  Recebe notificação push sobre a indicação, incluindo informações do indicador.
2. **Abrir Notificação:** Clica na notificação.
3. **Detalhes da Indicação:** Visualiza detalhes da indicação e os benefícios oferecidos.
4. **Aceitar/Recusar:** Escolhe aceitar ou recusar a indicação.
5. **Aceitou:** Preenche seus dados e confirma.
6. **Recusou:** Recebe mensagem de agradecimento.
7. **Aprovação (Indicado):** Após aprovação do seguro, recebe notificação com o desconto aplicado e informações de contato do consultor.


### Fluxo 3: Administrador - Gerenciamento de Indicadores e Indicados

1. **Login:** O administrador acessa o painel administrativo.
2. **Dashboard:** Visualiza métricas gerais (indicações, aprovações, descontos).
3. **Gerenciar Indicadores:** Acessa lista de indicadores, visualizando suas atividades e performance.
4. **Gerenciar Indicados:** Acessa lista de indicados, visualizando seus status e informações.
5. **Gerenciar Seguros:** Cadastra e gerencia os seguros disponíveis para indicação.
6. **Relatórios:** Gera relatórios sobre as indicações e desempenho do aplicativo.


### Fluxo 4: Indicador - Gerenciar Indicações

1. **Login:** O indicador acessa o aplicativo.
2. **Minhas Indicações:** Acessa a seção "Minhas Indicações".
3. **Visualizar Indicações:** Visualiza o status de cada indicação (pendente, aprovada, recusada).
4. **Detalhes da Indicação:**  Acessa detalhes de cada indicação, incluindo dados do indicado e status.


### Fluxo 5: Indicado - Resgatar Desconto

1. **Login:** O indicado acessa o aplicativo.
2. **Minhas Indicações:** Acessa a seção "Minhas Indicações".
3. **Indicação Aprovada:** Seleciona uma indicação aprovada.
4. **Resgatar Desconto:** Clica em "Resgatar Desconto".
5. **Confirmação:** Confirma o resgate do desconto.
6. **Sucesso:** Recebe mensagem de confirmação do desconto aplicado.



## Navegação

A navegação será intuitiva, utilizando menus de navegação inferior para acesso rápido às seções principais (Home, Minhas Indicações, Perfil).  As telas serão organizadas de forma clara e hierárquica, facilitando a navegação entre as diferentes funcionalidades.


## Interações

As interações serão simples e amigáveis, utilizando botões claros e mensagens de feedback em cada etapa do processo. O aplicativo terá suporte a notificações push para manter os usuários atualizados sobre o status de suas indicações.  A interface será responsiva, adaptando-se a diferentes tamanhos de tela.
