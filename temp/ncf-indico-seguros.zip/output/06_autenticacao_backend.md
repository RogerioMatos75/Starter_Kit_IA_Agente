# 06_autenticacao_backend.md

## Sugestão de Autenticação Backend para NCF-Indico-Seguros

### Método de Autenticação: JWT (JSON Web Token)

### Fluxo de Autenticação:

1. **Registro:** O usuário fornece suas credenciais (email e senha) para criar uma conta.  A senha deve ser criptografada usando uma função de hash unidirecional robusta (ex: bcrypt, Argon2).
2. **Login:** O usuário fornece suas credenciais. O backend verifica as credenciais contra o banco de dados. Se as credenciais forem válidas, um JWT é gerado.
3. **JWT Geração:** O JWT contém uma carga útil com informações do usuário (ID, email, tipo de usuário - administrador, assegurado, etc.), um tempo de expiração e uma assinatura criptográfica.  A assinatura é gerada usando uma chave secreta mantida em ambiente seguro (variável de ambiente, por exemplo).
4. **Autenticação em Requisições:**  O cliente envia o JWT em cada requisição subsequente, geralmente no cabeçalho `Authorization: Bearer <token>`.
5. **Validação do JWT:** O backend valida a assinatura do JWT para verificar sua autenticidade e integridade.  Verifica também a data de expiração.
6. **Acesso às funcionalidades:** Se o JWT for válido, o usuário tem acesso às funcionalidades correspondentes ao seu tipo de usuário.
7. **Logout:** A remoção do JWT do cliente (limpar cookies, armazenamento local) invalida o acesso.  Opcionalmente, um endpoint de logout pode invalidar o token no backend (lista negra).

### Tecnologias/Bibliotecas:

* **Linguagem de Programação:** Node.js com Express.js (ou outra linguagem/framework como Python com Django/Flask, Ruby on Rails, etc.)
* **Biblioteca JWT:** jsonwebtoken (Node.js), PyJWT (Python), etc.
* **Banco de Dados:** PostgreSQL, MySQL, MongoDB (ou similar, escolhendo a melhor opção para o projeto).
* **Criptografia de Senha:** bcrypt, Argon2.

### Considerações de Segurança:

* **Chave Secreta:** Manter a chave secreta usada para assinar os JWT em ambiente seguro, **nunca** no código-fonte. Utilizar variáveis de ambiente.
* **HTTPS:**  Utilizar HTTPS para todas as comunicações entre o cliente e o backend para proteger as informações em trânsito.
* **Validação de Dados:** Validar todas as entradas do usuário para prevenir injeção de SQL e outros ataques.
* **Proteção contra ataques de força bruta:** Implementar mecanismos de proteção contra ataques de força bruta, limitando o número de tentativas de login.
* **Atualizações de segurança:** Manter as dependências de software atualizadas para corrigir vulnerabilidades de segurança.
* **Token Revogação:** Implementar um mecanismo para revogar tokens, seja através de uma lista negra ou expirando o token antecipadamente em caso de suspeita de comprometimento.
* **Segurança de armazenamento de senhas:** Utilizar uma função de hash unidirecional robusta e salting para armazenar as senhas.  Nunca armazenar senhas em texto plano.
* **Auditoria:** Implementar logs de acesso para monitorar e auditar as atividades do sistema.
* **Proteção contra CSRF (Cross-Site Request Forgery):** Utilizar tokens CSRF para proteger contra ataques CSRF.


