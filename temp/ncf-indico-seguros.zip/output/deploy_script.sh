```bash
#!/bin/bash

# Verifica se o ambiente está configurado corretamente
if [ -z "$DEPLOY_ENV" ]; then
  echo "Erro: Variável de ambiente DEPLOY_ENV não definida. Exemplo: export DEPLOY_ENV=production"
  exit 1
fi

if [ -z "$APP_NAME" ]; then
  echo "Erro: Variável de ambiente APP_NAME não definida. Exemplo: export APP_NAME=meu-aplicativo"
  exit 1
fi

if [ -z "$ARTIFACT_PATH" ]; then
  echo "Erro: Variável de ambiente ARTIFACT_PATH não definida. Exemplo: export ARTIFACT_PATH=/path/to/meu-aplicativo.jar"
  exit 1
fi

# Verifica se o artefato existe
if [ ! -f "$ARTIFACT_PATH" ]; then
  echo "Erro: Artefato '$ARTIFACT_PATH' não encontrado."
  exit 1
fi


# Realiza o deploy para o ambiente especificado
echo "Iniciando deploy para o ambiente: $DEPLOY_ENV"

case "$DEPLOY_ENV" in
  production)
    # Comandos específicos para deploy em produção
    echo "Copiando o artefato para o servidor de produção..."
    scp "$ARTIFACT_PATH" user@production-server:/path/to/deploy

    echo "Parando o aplicativo..."
    ssh user@production-server "sudo systemctl stop $APP_NAME"

    echo "Copiando o artefato para a pasta de deploy..."
    ssh user@production-server "sudo mv /path/to/deploy/$APP_NAME.jar /opt/apps/$APP_NAME/"

    echo "Iniciando o aplicativo..."
    ssh user@production-server "sudo systemctl start $APP_NAME"

    echo "Verificando o status do aplicativo..."
    ssh user@production-server "sudo systemctl status $APP_NAME"
    ;;
  staging)
    # Comandos específicos para deploy em staging
    echo "Deploy para staging não implementado."
    exit 0
    ;;
  *)
    echo "Ambiente de deploy '$DEPLOY_ENV' inválido."
    exit 1
    ;;
esac

echo "Deploy concluído com sucesso!"
exit 0
```
